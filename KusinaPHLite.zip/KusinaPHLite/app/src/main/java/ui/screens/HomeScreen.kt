package com.example.kusinaphlite.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.kusinaphlite.ui.viewmodel.MealViewModel

@Composable
fun HomeScreen(navController: NavController, viewModel: MealViewModel) {
    val meals by viewModel.meals.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadMeals()
    }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Filipino Meals", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        meals.forEach { meal ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable {
                        navController.navigate("detail/${meal.idMeal}")
                    }
            ) {
                Text(meal.strMeal, modifier = Modifier.padding(16.dp))
            }
        }
    }
}
