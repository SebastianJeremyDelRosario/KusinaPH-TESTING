package com.example.kusinaphlite.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kusinaphlite.data.model.Meal
import com.example.kusinaphlite.data.repository.MealRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MealViewModel : ViewModel() {
    private val repository = MealRepository()

    private val _meals = MutableStateFlow<List<Meal>>(emptyList())
    val meals: StateFlow<List<Meal>> = _meals

    private val _selectedMeal = MutableStateFlow<Meal?>(null)
    val selectedMeal: StateFlow<Meal?> = _selectedMeal

    fun loadMeals(category: String = "Seafood") {
        viewModelScope.launch {
            _meals.value = repository.getMeals(category)
        }
    }

    fun loadMealDetail(id: String) {
        viewModelScope.launch {
            _selectedMeal.value = repository.getMealDetails(id)
        }
    }
}
