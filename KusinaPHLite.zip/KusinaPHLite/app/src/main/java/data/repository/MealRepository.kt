package com.example.kusinaphlite.data.repository

import com.example.kusinaphlite.data.model.Meal
import com.example.kusinaphlite.data.network.RetrofitClient

class MealRepository {
    private val api = RetrofitClient.apiService

    suspend fun getMeals(category: String): List<Meal> {
        return api.getMealsByCategory(category).meals
    }

    suspend fun getMealDetails(id: String): Meal {
        return api.getMealDetails(id).meals.first()
    }
}
